#include <string>
#include <iostream>

using namespace std;

class Crow {
private:
	string name;
	int hungerLevel;
	string color;
	const int MIN_GORGE_LEVEL = 50;

public:
/*	Crow()
	{
		name = "Fred";
		hungerLevel = 80;
		color = "grey";
		cout << "It's so good to be born!" << endl;
	}
	*/

	Crow(string name, int hungerLevel, string color)
	{
		this->name = name;
		this->hungerLevel = hungerLevel;
		this->color = color;
		cout << "It's so good to be born!" << endl;
	}


	void setName(string name);

	void setHungerLevel(int hungerLevel)
	{
		this->hungerLevel = hungerLevel;
	}

	void setColor(string color)
	{
		this->color = color;
	}

	string getName()
	{
		return name;
	}

	int getHungerLevel()
	{
		return hungerLevel;
	}

	string getColor()
	{
		return color;
	}

	bool isHungry()
	{
		return hungerLevel > MIN_GORGE_LEVEL;
	}

	void gorge(int junkFood)
	{
		if (hungerLevel > MIN_GORGE_LEVEL)
		{
			hungerLevel -= junkFood;
		}
		junkFood += 50;
		cout << "inside heckel, the value of junkFood is " << junkFood << endl;
	}
};

void Crow::setName(string name)
{
	this->name = name;
}

int main()
{
	Crow heckle;
	
	cout << heckle.getName() << " is a crow, with stylish "
		 << heckle.getColor() << " plumage." << endl;

	heckle.setName("Sir Heckle");
	heckle.setHungerLevel(100);
	heckle.setColor("jet black");

	cout << heckle.getName() << " is a crow, with stylish "
		 << heckle.getColor() << " plumage." << endl;

	cout << heckle.getName() << "'s hunger level before gorging is "
		<< heckle.getHungerLevel() << endl;
/*
	int bigMac = 25;
	heckle.gorge(bigMac);

	cout << "outside heckel, the value of junkFood is " << bigMac << endl;

	cout << heckle.getName() << "'s hunger level after gorging is " 
		 << heckle.getHungerLevel() << endl;

*/
	Crow jeckle("Jeckel", 85, "striped");
	cout << jeckle.getName() << " is a crow, with stylish "
		 << jeckle.getColor() << " plumage." << endl;

	if (jeckle.isHungry())
	{
		cout << jeckle.getName() << " is hungry!" << endl;
	}

	cout << "The address of jeckle is " << &jeckle << endl;

	char c;
	cout << "Please hit any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}
