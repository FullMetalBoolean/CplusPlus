#include <iostream>
int main(){std::cout<<"Hello world!"<<std::endl;char c;
  std::cout<<"Please any key and <ENTER> to continue..."<<
    std::endl;std::cin>>c;}
