#include <iostream>

using namespace std;

int main()
{
      //cout<<"Hello world!"<<endl;
        cout << "Hello world!" << endl;
	
	char c;
        cout << "Please any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}
