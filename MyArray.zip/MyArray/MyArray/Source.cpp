#include <iostream>

using namespace std;

int main()
{
	const int ROWS = 8;

	int myArray[ROWS]; // = { 2, 4,  6,  8, 10, 12, 14, 16 };

	myArray[2] = 42;

	cout << "Can we glimpse the Matrix?" << endl << endl;
	for (int row = 0; row < ROWS; row++)
	{
		cout << myArray[row] << " ";
		cout << endl;
	}
	cout << endl << endl;

	cout << "We predict that myArray[3] is 8: " << myArray[3] << endl;

	cout << endl << endl;

	cout << "Please press any key and <ENTER> to continue..." << endl;
	char c;
	cin >> c;

	return 0;
}
