#include <iostream>

using namespace std;

int main()
{
	cout << "Hello world!" << endl;

	bool done = false;

	do  // Start of game loop
	{
		int scoop_count = 0;

		const int NUM_LIMIT = 1000;

		bool serving = true;
		do
		{
			if (scoop_count >= NUM_LIMIT)
			{
				serving = false;
			}

			scoop_count++;

			cout << "do something..." << endl;
		} while (serving);


		cout << "We served " << scoop_count
			<< " scoops of ice cream!"
			<< endl;

		bool valid = false;
		do
		{
			cout << "Would you like to play again? (y/n)" << endl;
			char ans;
			cin >> ans;

			switch (ans)
			{
			case 'y':
			case 'Y':
				valid = true;
				break;
			case 'n':
			case 'N':
				valid = true;
				done = true;
				break;
			default:
				cout << "You must enter either a 'y' or a 'n'." << endl;
				cout << "Please enter 'y' or 'n'." << endl;
				cin >> ans;
				break;
			}
		} while (!valid);

	} while (!done);  // End of game loop

	char c;
	cout << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;
}