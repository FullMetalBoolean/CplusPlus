#include <iostream>

using namespace std;

int main()
{
	cout << "Hello world!" << endl;

	char c;
	cout << endl << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;

	cout << c;

	return 0;
}