#include <iostream>

using namespace std;


void foo(int num);

int main()
{
    int number;
    int anotherNum;

    number = 15;
    foo(number);

    cout << "main num is " << num << endl;


    char c;
    cout << "Please press any key and <ENTER> to continue..." << endl;
    cin >> c;

    return 0;
}

void foo(int num)
{
    int x;

    cout << "What is the nature of foo?" << endl << endl;
    num *= 10;

    cout << "foo num is " << num << endl;
}
