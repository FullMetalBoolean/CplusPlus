#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

class Bird {
public:
	Bird(string color, int size, string name)
	{
		setColor(color);
		setSize(size);
		setName(name);
	}

	void setColor(string color)
	{
		this->color = color;
	}

	string getColor()
	{
		return color;

	}

    void setSize(int size)
	{
		this->size = size;
	}

    void setName(string name)
	{
		this->name = name;
	}

	// Add sets and gets for both size and name
	void displayProperties()
	{
		cout << "Color: "<< color << endl;
		cout << "size: " << size << endl;
		cout << "name: " << name << endl;
	}

private:
	string color;
	int size;
	string name;
};

int main()
{
	Bird crow("black", 3, "Heckel");
	crow.displayProperties();
	return 0;
}

