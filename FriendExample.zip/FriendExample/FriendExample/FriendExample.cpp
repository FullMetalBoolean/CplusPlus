#include "FriendExample.h"



FriendExample::FriendExample()
{
}


FriendExample::~FriendExample()
{
}
