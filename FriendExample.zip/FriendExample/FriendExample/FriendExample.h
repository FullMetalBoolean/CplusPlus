#pragma once

#include <iostream>

using namespace std;

class Lion
{
	int teeth, claws;
	int waterDish;

public:
	Lion()
	{
		teeth = 10;
		claws = 20;
		waterDish = 0;
	}

	friend class Caretaker;        //Statement 1
};

class Caretaker
{
	Lion* lionPtr;
	int water;

public:
	Caretaker(Lion* lionPtr)
	{
		this->lionPtr = lionPtr;
		water = 5;
	}

	void careForLion()
	{
		if (lionPtr)
		{
			lionPtr->waterDish = water;
			water = 0;
		}
	}

	void display(Lion lion)
	{
		cout << "\n\n\tteeth : " << lion.teeth;
		cout << "\n\n\tclaws : " << lion.claws;
		cout << "\n\n\twater : " << water;
		cout << "\n\n\n\twater dish: " << lion.waterDish << endl;
	}
};

class FriendExample
{
public:
	FriendExample();
	~FriendExample();

	void display()
	{
		Lion lion;
		Caretaker caretaker(&lion);

		caretaker.careForLion();
		caretaker.display(lion);
	};
};

void main()
{
	FriendExample friendExample;
	friendExample.display();

	char c;
	cout << "Press any key and <ENTER> to continue..." << endl;
	cin >> c;
}


