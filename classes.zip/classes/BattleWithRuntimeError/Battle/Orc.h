#ifndef ORC_H
#define ORC_H

#include <string>
#include <iostream>

using namespace std;

const int ORC_WEAPONS_NUM = 5;
const int ORC_BUDDY_NUM = 4;

class Orc
{
public:
	Orc();
	Orc(int size);
	void initBuddies();

	~Orc();

	void setBuddyObj(int index);

	void setBuddySize(int index, int size);
	int getBuddySize(int index);

	int getStrength();
	void setStrength(int strength);

	int getHealth();
	void setHealth(int health);

	int getSize();
	void setSize(int size);

	string getColor();
	void setColor(string color);

	string getWeapon(int index);
	void setWeapon(int index, string weapon);

private:
	void init();

	int strength;
	int health;
	int size;
	string color;
	string weapons[ORC_WEAPONS_NUM];

	Orc* buddies[ORC_BUDDY_NUM];

	static int count;
};



#endif

