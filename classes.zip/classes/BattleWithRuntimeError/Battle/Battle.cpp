#include <iostream>

#include "Orc.h"

using namespace std;

int main()
{
	Orc* grokPtr = new Orc();

	grokPtr->initBuddies();

	grokPtr->setBuddyObj(0);
	grokPtr->setBuddyObj(1);
	grokPtr->setBuddyObj(2);
	grokPtr->setBuddyObj(3);

	grokPtr->setBuddySize(0, 15000);
	grokPtr->setBuddySize(0, 1500);
	grokPtr->setBuddySize(0, 150);
	grokPtr->setBuddySize(0, 15);

	for (int i = 0; i < ORC_BUDDY_NUM; i++)
	{
		cout << "Grok's " << i << " buddy's size is " << grokPtr->getBuddySize(i) << endl;
	}

//	Orc groma(50);

	cout << "Grok's size is " << grokPtr->getSize() << endl;
	//cout << "Groma's size is " << groma.getSize() << endl;

	delete grokPtr;

	char c;
	cout << "Please enter any key and <ENTER> to continue..." << endl;
	cin >> c;
}
