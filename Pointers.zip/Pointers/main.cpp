#include <iostream>

using namespace std;

int main()
{
    cout << "Kombucha!" << endl;

    int numbers[] = {42, 8, 16, 57};
    int quantity;

    quantity = 76;

    cout << "quantity = " << quantity << endl;
    cout << "numbers[1] is " << numbers[1] << endl;

    cout << "The address of quantity is " << &quantity << endl;
    cout << "The value at location " << &quantity << " is " << quantity << endl;

    int* somePtr;

    somePtr = &quantity;

    cout << "The value of somePtr is " << somePtr << endl;
    cout << "The value that somePtr points to is " << *somePtr << endl;

    cout << "The value of numbers is " << numbers << endl;
    cout << "The value that numbers[2] has is " << numbers[2] << endl;
    cout << "The value of numbers[2] is " << numbers + 2 << endl;
    cout << "The value of &(numbers[2]) is " << &(numbers[2]) << endl;

    int count = 0;
    while(count < 4)
    {
        cout << "numbers[" << count << "] is " << numbers[count] << endl;
        count++;
    }

    while(count < 4)
    {
        cout << "numbers[" << count << "] is " << numbers[count] << endl;
        count++;
    }

    int* myIntPtr;
    myIntPtr = numbers;

    while(true)
    {
        cout << "myIntPtr[" << count << "] is " << myIntPtr[count] << endl;
        *(myIntPtr + count) = 42;
        count++;
    }

    char c;
    cout << "Please press any key and <ENTER> to continue..." << endl;
    cin >> c;

    return 0;
}
