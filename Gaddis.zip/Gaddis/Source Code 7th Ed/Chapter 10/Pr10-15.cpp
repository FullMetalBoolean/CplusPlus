// This program demonstrates the string class.
#include <iostream>
#include <string>    // Required for the string class.
using namespace std;

int main()
{
   string movieTitle;

   movieTitle = "Wheels of Fury";
   cout << "My favorite movie is " << movieTitle << endl;
   return 0;
}