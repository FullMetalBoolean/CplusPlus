#include <string>
#include <iostream>

using namespace std;

bool isValidNum(int& numRef, int lowerLimit, int upperLimit);

int main()
{
	int num;
	
	cout << "Please enter a number between 1 and 100: ";

	isValidNum(num, 1, 100);

	cout << endl << num << " is a good number!" << endl;

	char c;
	cout << "Please hit any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}


bool isValidNum(int& numRef, int lowerLimit, int upperLimit)
{
	int number;

	bool validInput = true;
	do {
		cin >> number;

		if (number < lowerLimit || number > upperLimit)
		{
			if (number < 0)
			{
				numRef = -1;
				return false;
			}
			validInput = false;
			cout << "Sorry, the number must be from 1 to 100." << endl;
			cout << "Please try again: ";
		}
		else
		{
			validInput = true;
		}
	} while (!validInput);

	numRef = number;

	return true;
}