#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	int count = 0;
	const int MAX_COUNT = 1000;
	bool counting = true;

	const int MIN_VAL = 1;
	const int MAX_VAL = 10;

	int range = (MAX_VAL - MIN_VAL) + 1;

	srand(static_cast<unsigned int> (time(0)));

	/*
	 * This is
	 * an example of
	 * multi-line
	 * commenting.
	 */


	/*
	do
	{
		cout << MIN_VAL + (rand() % range) << endl;
		//cout << rand() % range << endl;


		if (count >= MAX_COUNT)
		{
			counting = false;
		}
		count++;
	} while (counting);
	*/

	for (int i = 0; i < MAX_COUNT; i++)
	{
		for (int j = 0; j < MAX_COUNT; j++)
		{
			cout << "i = " << i << "\tj = " << j << endl;
		}
	}

	char c;
	cout << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}