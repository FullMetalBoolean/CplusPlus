#include <iostream>

using namespace std;



int main()
{
	int* numbers = NULL;      // Pointer to int, initialize to null pointer.
	int size;                 // Size needed for array

	cout << "Please specify the size of the array that you need: ";
	cin >> size;              // Read in the size from the user

	numbers = new int[size];  // Allocate memory for "size" ints and save pointer value in numbers.

	cout << endl;

	for (int i = 0; i < size; i++)
	{
		numbers[i] = 0;    // Initialize all elements to zero.
	}

	cout << "Please enter all values..." << endl;

	for (int i = 0; i < size; i++)
	{
		cin >> numbers[i];
	}

	cout << endl;

	for (int i = 0; i < size; i++)
	{
		cout << numbers[i] << endl;
	}

	cout << endl;

	cout << "Please press any key and <ENTER> to continue..." << endl;
	char c;
	cin >> c;

	delete[] numbers;  // When done, free memory pointed to by a.
	numbers = NULL;     // Clear a to prevent using invalid memory reference.
}