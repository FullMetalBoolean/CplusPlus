#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Bear
{
public:
    Bear()
    {
        srand(static_cast<unsigned int> (time(0)));
        setFavoriteNum(getRandomNum());
        lowerBound = 1;
        upperBound = 10;
        cout << "I'm a hungry bear!... and you look very tasty today." << endl;
    }

    void doStuff()
    {
        int i;
        for(i = 0; i < 10000; i++)
        {
            cout << "i is " << i << endl;
        }
    }

    int getRandomNum()
    {
        return lowerBound + (rand() % (upperBound - lowerBound + 1));
    }

    void setFavoriteNum(int favoriteNumInp)
    {
        favoriteNum = favoriteNumInp;
    }

    int getFavoriteNum()
    {
        return favoriteNum;
    }

    void setLowerBound(int lowerBoundInp)
    {
        lowerBound = lowerBoundInp;
    }

    int getLowerBound()
    {
        return lowerBound;
    }

    void setUpperBound(int upperBoundInp)
    {
        upperBound = upperBoundInp;
    }

    int getUpperBound()
    {
        return upperBound;
    }

private:
    int favoriteNum;
    int lowerBound;
    int upperBound;
};



int main()
{
    Bear smokey;

    //smokey.setFavoriteNum(42);

    smokey.setUpperBound(6);

    cout << "Smokey gave me this pseudorandom number: " << smokey.getRandomNum() << endl;

    cout << "Smokey says that " << smokey.getFavoriteNum() << " is his favorite number." << endl;

    smokey.doStuff();

    return 0;
}
