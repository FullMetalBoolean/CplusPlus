#include <iostream>


using namespace std;

double foo(int x);
double foo(double x);

int main()
{
	double fooReturnVal;

	int three = 3;

	for (int i = 0; i < 10; i++)
	{
		fooReturnVal = foo(three) * 1000;

		cout << "fooReturnVal is " << fooReturnVal << endl;
		cout << "three is " << three << endl;
	}

	foo(4.56);

	char c;
	cout << endl << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}

double foo(int x)
{
	x *= 2;

	int someNumber;

	someNumber = 42.5;

	cout << "I like toast!" << endl;
	cout << "I also like jam!" << endl;
	cout << endl;

	return someNumber * x;
}

double foo(double x)
{
	cout << endl << "Doubles are awesome!" << endl;

	cout << endl;

	return x * 2;
}