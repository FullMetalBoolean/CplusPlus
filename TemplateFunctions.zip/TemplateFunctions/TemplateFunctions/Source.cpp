#include <iostream>

using namespace std;

/*
int square(int number)
{
	return number * number;
}

double square(double number)
{
	return number * number;
}
*/

template<class T>
T square(T number)
{
	return number * number;
}


int main()
{
	cout << "The square of 3 is " << square(3) << endl;

	cout << "The square of 3.5 is " << square(3.5) << endl;

	if ("99999" < "one")
	{
		cout << "99999 is less than one" << endl;
	}
	else
	{
		cout << "99999 is not less than one" << endl;
	}

	char c;
	cout << endl << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;
}