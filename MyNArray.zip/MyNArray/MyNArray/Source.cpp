#include <iostream>

using namespace std;

int main()
{
	const int ROWS = 4;
	const int COLS = 8;

	int twoDimArray[ROWS][COLS] =
	{ {2, 4,  6,  8, 10, 12, 14, 16},
	  {4,  6,  8, 10, 12, 14, 16, 18},
	  {6,  8, 10, 12, 14, 16, 18, 20},
	  {8, 10, 12, 14, 16, 18, 20, 22},
	};

	cout << "Can we see the Matrix?" << endl << endl;
	for (int row = 0; row < ROWS; row++)
	{
		cout << "This is row " << row << " --> ";
		for (int col = 0; col < COLS; col++)
		{
			cout << twoDimArray[row][col] << " ";
		}
		cout << endl;
	}
	cout << endl << endl;

	cout << "We predict that twoDimArray[1][3] is 10: " << twoDimArray[1][3] << endl;

	cout << endl << endl;

	cout << "Please press any key and <ENTER> to continue..." << endl;
	char c;
	cin >> c;

	return 0;
}