#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	bool guessing;
	const int MIN_VAL = 1;
	const int MAX_VAL = 100;
	int guess;
	int range = (MAX_VAL - MIN_VAL) + 1;
	int randomNum;
	int attempts;

	char c;



	srand(static_cast<unsigned int> (time(0))); //seeding causes random number to not be the same ever time the program is run

	bool playing = true;
	char ans;

	do
	{
		randomNum = MIN_VAL + (rand() % range);

		cout << "I have a random number from 1 to 100. Can you guess what it is?" << endl;
		cout << " " << endl;

		attempts = 0;
		guessing = true;
		while (guessing)
		{
			cout << "Please enter your guess" << endl;
			cin >> guess;

			attempts++;

			if (guess > MAX_VAL || guess < MIN_VAL)
			{
				cout << "Your guess is out of range, try again." << endl;
				cout << " " << endl;
			}

			else if (guess > randomNum)
			{
				cout << "Too high, try again" << endl;
				cout << " " << endl;
			}

			else if (guess < randomNum)
			{
				cout << "Too low, try again." << endl;
				cout << " " << endl;
			}

			else
			{
				cout << "Ha Ha! You got it! The number was " << randomNum << endl;
				cout << attempts << " attempts were made!" << endl;
				cout << "Please press any key and <ENTER> to continue..." << endl;
				guessing = false;
			}
		}

		cout << "Would you like to play again? Y or N" << endl;
		cin >> ans;

		bool validInput = false;
		do
		{
			switch (ans)
			{
			case 'Y':
			case 'y':
				validInput = true;
				break;
			case 'N':
			case 'n':
				playing = false;
				validInput = true;
				break;
			default:
				cout << "Please press Y or N" << endl;
				break;
			};
		} while (!validInput);
	} while (playing);

	cout << "Thanks for playing! Please press any key and <ENTER> to exit..." << endl;
	cin >> c;

	return 0;
}