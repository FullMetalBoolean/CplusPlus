#include "Hawk.h"
#include <iostream>

using namespace std;

Hawk::Hawk()
{}

Hawk::Hawk(int willToLive) : Bird(willToLive), talonLength(5)
{}

void Hawk::sing()
{
	cout << "Screech, screech, screech..." << endl;
}

Hawk::~Hawk()
{
	cout << "While I'm still living, I can see much better than you!" << endl;
}
