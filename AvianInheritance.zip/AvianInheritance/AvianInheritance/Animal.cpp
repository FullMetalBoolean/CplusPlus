#include "Animal.h"

#include <iostream>

using namespace std;

Animal::Animal()
{
	cout << "I'm an animal... and I just came into existence. So what's this strange Universe all about?" << endl;
}

Animal::Animal(int willToLive)
{
	cout << "I'm an animal... and I just came into existence. So what's this strange Universe all about?" << endl;
	this->willToLive = willToLive;
}

int Animal::getWillToLive()
{
	return willToLive;
}

void Animal::sing()
{
	cout << "la la la..." << endl;
}

Animal::~Animal()
{
	cout << "I'm an animal, and I'm dying... What they say is true: death is, indeed, the great equalizer!" << endl;
}
