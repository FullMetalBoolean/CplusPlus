#ifndef BIRD_H_
#define BIRD_H_

#include "Animal.h"

class Bird : public Animal
{
public:
	Bird();
	Bird(int willToLive);
	virtual void sing();

	virtual ~Bird();

	void setWingSpan(int wingSpan);
	int getWingSpan();

private:
	int wingSpan;
};

#endif


