#include "Animal.h"
#include "Bird.h"
#include "Hawk.h"
#include <iostream>

using namespace std;

int main()
{
	if (true)
	{
		Animal critter(50);
		cout << "The critter's will to live value is " + critter.getWillToLive() << endl;

		Bird sally(50);
		sally.setWingSpan(2);

		cout << "What happens to a local Animal object when the program leaves the scope in which the Animal was created?" << endl;
	}

	Hawk* hawkPtr = new Hawk(90);

	Animal* animalPtr = hawkPtr;

	animalPtr->sing();

	delete animalPtr;

	for (int i = 0; i < 5; i++)
	{
		Hawk hawk;
		cout << "My will to live value is " << hawk.getWillToLive() << " and my address is " << &hawk << endl;
	}

	char c;
	cout << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;
}