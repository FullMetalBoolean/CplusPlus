#ifndef ANIMAL_H_
#define ANIMAL_H_

class Animal
{
public:
	Animal();
	Animal(int willToLive);

	virtual void sing();

	int getWillToLive();

	virtual ~Animal();

protected:
	int willToLive;
};

#endif