#ifndef HAWK_H_
#define HAWK_H_

#include "Animal.h"
#include "Bird.h"

class Hawk : public Bird
{
public:
	Hawk();
	Hawk(int willToLive);
	virtual void sing();

	virtual ~Hawk();

private:
	int talonLength;
};

#endif
