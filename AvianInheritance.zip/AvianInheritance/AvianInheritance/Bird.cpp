#include "Bird.h"
#include <iostream>

using namespace std;

Bird::Bird()
{
}

Bird::Bird(int willToLive) : Animal(willToLive), wingSpan(3)
{}

void Bird::sing()
{
	cout << "Tweet, tweet, tweet,..." << endl;
}

void Bird::setWingSpan(int wingSpan)
{
	this->wingSpan = wingSpan;
}

int Bird::getWingSpan()
{
	return wingSpan;
}

Bird::~Bird()
{
	cout << "Bird's are well-known for their ability to die gloriously! (There's a reason why they call it a swan song!" << endl;
}
