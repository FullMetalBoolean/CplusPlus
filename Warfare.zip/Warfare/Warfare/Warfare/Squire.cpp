#include "Squire.h"
#include "Orc.h"

/*
Squire::Squire(Orc* orcPtr)
{
	this->orcPtr = orcPtr;
	name = "Sancho Panza";
	favoriteWeaponIndex = orcPtr->favoriteWeaponIndex;
	favoriteWeapon = orcPtr->weapons[favoriteWeaponIndex];
}
*/

Squire::Squire(Orc& orc) : orcRef(orc)
{
	orcRef.setSquirePtr(this);
	name = new string("Sancho Panza");
}


Squire::~Squire()
{
	delete name;
	cout << "I served my Orc Lord as best I could." << endl;
}


string Squire::getName()
{
	return *name;
}

void Squire::setName(string name)
{
	this->name = &name;
}

string Squire::getFavoriteWeapon()
{
	cout << "The squire favorite weapon index is " + orcRef.favoriteWeaponIndex << endl;
	return orcRef.weapons[orcRef.favoriteWeaponIndex];
}

void Squire::setFavoriteWeapon(string favoriteWeapon)
{
	this->favoriteWeapon = favoriteWeapon;
}

string Orc::getSquireName()
{
	return squirePtr->getName();
}

