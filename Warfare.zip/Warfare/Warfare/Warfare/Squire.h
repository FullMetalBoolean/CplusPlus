#ifndef SQUIRE_H
#define SQUIRE_H

#include <string>

class Orc;

using namespace std;

class Squire
{
public:
	Squire(Orc& orcRef);

	//Squire(const Orc& orcPtr);

	~Squire();

	string getName();
	void setName(string name);

	string getFavoriteWeapon();
	void setFavoriteWeapon(string favoriteWeapon);

private:
	string* name;
	//Orc* orcPtr;

	Orc& orcRef;
	string favoriteWeapon;
	int favoriteWeaponIndex;
};

#endif
