#ifndef ORC_H
#define ORC_H

#include <string>
#include <iostream>
#include "Squire.h"

using namespace std;

const int ORC_WEAPONS_NUM = 5;

class Orc
{
public:
	Orc();

	Orc(const Orc& orcRef);

	~Orc();

	int getStrength();
	void setStrength(int strength);

	int getHealth();
	void setHealth(int health);

	int getSize();
	void setSize(int size);

	string getColor();
	void setColor(string color);

	string getWeapon(int index);
	void setWeapon(int index, string weapon);

	void setFavoriteWeaponIndex(int favoriteWeaponIndex);

	void setSquirePtr(Squire* squirePtr);

	string getSquireName();

	friend class Squire;

private:
	void init();

	int strength;
	int health;
	int size;
	int favoriteWeaponIndex;

	string color;
	string weapons[ORC_WEAPONS_NUM];

	mutable Squire* squirePtr;
};



#endif

