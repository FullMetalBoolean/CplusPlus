#include <iostream>

#include "Orc.h"
#include "Squire.h"

using namespace std;

int main()
{
	Orc* grokPtr = new Orc();
	Orc groma(*grokPtr);

	//Squire* squirePtr = new Squire(grokPtr);
	Squire* squirePtr = new Squire(*grokPtr);
	Squire* anotherSquirePtr = new Squire(groma);

	cout << "The squire says that the Orc's favorite weapon is a " << squirePtr->getFavoriteWeapon() << endl;

	grokPtr->setFavoriteWeaponIndex(2);

	cout << "Another squire says that his Orc's favorite weapon is a " << anotherSquirePtr->getFavoriteWeapon() << endl;

	cout << "Grok's size is " << grokPtr->getSize() << endl;
	cout << "Groma's size is " << groma.getSize() << endl;

	cout << "Grok says his squire is " << grokPtr->getSquireName() << endl;
	cout << "Groma says his squire is " << groma.getSquireName() << endl;

	delete grokPtr;
	delete squirePtr;
	
	char c;
	cout << "Please enter any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}
