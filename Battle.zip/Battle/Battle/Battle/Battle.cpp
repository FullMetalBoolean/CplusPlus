#include <iostream>

#include "Orc.h"
#include "Squire.h"

using namespace std;

int main()
{
	Orc* grokPtr = new Orc();
	Orc groma(50);
	Squire squire;

	cout << "Grok's size is " << grokPtr->getSize() << endl;
	//cout << "Groma's size is " << groma.getSize() << endl;

	delete grokPtr;

	char c;
	cout << "Please enter any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}
