#include "Orc.h"

Orc::Orc()
{
	init();
}

Orc::Orc(int size)
{
	init();

	this->size = size;

	cout << "My coming into being is a glorious event!" << endl;
}

Orc::~Orc()
{
	cout << "Arghhh!!! (There are so many villages left unpillaged!)" << endl;
}

void Orc::init()
{
	strength = 10;
	health = 100;
	size = 10;
	color = "Green";
	weapons[0] = "club";
	weapons[1] = "axe";
	weapons[2] = "dagger";
	weapons[3] = "crossbow";
	weapons[4] = "sword";
	favoriteWeaponIndex = 3;
}

int Orc::getStrength()
{
	return strength;
}

void Orc::setStrength(int strength)
{
	this->strength = strength;
}

int Orc::getHealth()
{
	return health;
}

void Orc::setHealth(int health)
{
	this->health = health;
}

int Orc::getSize()
{
	return size;
}

void Orc::setSize(int size)
{
	this->size = size;
}

string Orc::getColor()
{
	return color;
}

void Orc::setColor(string color)
{
	this->color = color;
}

string Orc::getWeapon(int index)
{
	return weapons[index];
}

void Orc::setWeapon(int index, string weapon)
{
	weapons[index] = weapon;
}
