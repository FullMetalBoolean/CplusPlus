#ifndef ORC_H
#define ORC_H

#include <string>
#include <iostream>

using namespace std;

const int ORC_WEAPONS_NUM = 5;

class Orc
{
public:
	Orc();
	Orc(int size);

	~Orc();

	int getStrength();
	void setStrength(int strength);

	int getHealth();
	void setHealth(int health);

	int getSize();
	void setSize(int size);

	string getColor();
	void setColor(string color);

	string getWeapon(int index);
	void setWeapon(int index, string weapon);

private:
	void init();

	int strength;
	int health;
	int size;
	string color;
	string weapons[ORC_WEAPONS_NUM];
};



#endif

