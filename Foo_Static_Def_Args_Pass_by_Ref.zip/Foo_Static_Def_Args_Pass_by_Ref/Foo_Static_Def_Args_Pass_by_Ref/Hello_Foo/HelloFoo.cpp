#include <iostream>


using namespace std;

double foo(int& x);
//double foo(double x);

int main()
{
	double fooReturnVal;

	int three = 3;

	/*
	for (int i = 0; i < 10; i++)
	{
//		fooReturnVal = foo(three) * 1000;
		fooReturnVal = foo(three) * 1000;
		cout << "fooReturnVal is " << fooReturnVal << endl;
		cout << "three is " << three << endl;
	}
	*/

	foo(three);

	cout << "After foo(three), three is " << three << endl;

	//foo(4.56);

	char c;
	cout << endl << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;

	return 0;
}

//double foo(int x)

double foo(int& x)
{
	static int count = 0;

	cout << "x = " << x << endl;

	x *= 2;

	int someNumber;

	someNumber = 42;

	cout << "I like toast!" << endl;
	cout << "I also like jam!" << endl;
	cout << endl;

	const int MAX_VAL = 1000;
	for (int i = 0; i < MAX_VAL; i++)
	{
		count++;
	}

	cout << "count is " << count << endl;

	return someNumber * x;
}

/*
double foo(double x)
{
	cout << endl << "Doubles are awesome!" << endl;

	cout << endl;

	return x * 2;
}
*/