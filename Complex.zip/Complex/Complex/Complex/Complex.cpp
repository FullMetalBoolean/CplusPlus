#pragma once
#include <iostream>

using namespace std;


class Complex
{
	friend Complex operator+(const Complex  &lhs, const Complex &rhs);
	friend istream& operator>>(istream &in, Complex &c);   //input
	friend ostream& operator<<(ostream &out, Complex &c);  //output

public:
	Complex(double re, double im)
		:real(re), imag(im)
	{};

private:
	double real;
	double imag;
};

Complex operator+(const Complex& lhs, const Complex&  rhs)
{
	double result_real = lhs.real + rhs.real;
	double result_imaginary = lhs.imag + rhs.imag;
	return Complex(result_real, result_imaginary);
}


istream& operator>>(istream& in, Complex& c)     //input
{
	cout << "enter real part:\n";
	in >> c.real;
	cout << "enter imag part: \n";
	in >> c.imag;
	return in;
}

ostream& operator<<(ostream& out, Complex& c)     //output
{
	out << "real part: " << c.real << "\n";
	out << "imag part: " << c.imag << "\n";
	return out;
}

void main()
{
	cout << "Demonstrating use of complex class to represent complex numbers." << endl;

	Complex a(1.2, 1.3);     //this class is used to represent complex numbers
	Complex b(2.1, 3);       //notice the construction taking 2 parameters for the real and imaginary part
	Complex c = a + b;        //for this to work the addition operator must be overloaded

	cout << "a:\n" << a << endl;
	cout << "b:\n" << b << endl;
	cout << "c:\n" << c << endl;

	cout << "Please press any key and <ENTER to continue..." << endl;
	char holdConsole;
	cin >> holdConsole;
}


