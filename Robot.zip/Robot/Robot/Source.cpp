#include <iostream>

using namespace std;

class Robot
{
private:
	int x;
	int y;

public:
	Robot()
	{
		x = 0;
		y = 0;
	}

	void move(int xOffset, int yOffset)
	{
		x += xOffset;
		y += yOffset;
	}

	void showPos()
	{
		cout << "x is " << x << endl;
		cout << "y is " << y << endl;
	}
};



int main()
{
	Robot robbie;

	robbie.showPos();
	robbie.move(5, 15);
	robbie.showPos();

	char c;
	cout << "Please press any key and <ENTER> to continue..." << endl;
	cin >> c;
}

