#include <iostream>
#include <cstdlib>  // We need this for rand and srand
#include <ctime>    // This will give us the system time

using namespace std;

int main()
{
	// Initialize the seed
	unsigned int seed = static_cast<unsigned int> (time(0));

	// Seed the random number generator
	srand(seed);

	// Declare number variable
	int number;

	// Assign to number a random value
	number = rand();

	// Display number
	cout << number << endl;

	const int LOWER_BOUND = 1;
	const int UPPER_BOUND = 6;

	int betterNumber = (number % UPPER_BOUND) + LOWER_BOUND;

	cout << "A better number would be... " << betterNumber << endl;

	// Assign to number another random value
	number = rand();

	// Display number again
	cout << number << endl;

	bool again = true;

	while (again)
	{

		for (int i = 0; i < 10; i++)
		{
			cout << rand() << endl;
			cout << rand() << endl;
			cout << rand() << endl;
		}

		cout << "Do you want to play again? (y/n)" << endl;
		char ans;

		cin >> ans;

		if ((ans == 'n') || (ans == 'N'))
		{
			again = false;
		}
	}

	return 0;
}
